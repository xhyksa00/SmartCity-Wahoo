from django.apps import AppConfig


class SmartcityAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'smartcity_app'
