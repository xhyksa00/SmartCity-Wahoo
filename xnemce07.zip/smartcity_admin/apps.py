from django.apps import AppConfig


class SmartcityAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'smartcity_admin'
